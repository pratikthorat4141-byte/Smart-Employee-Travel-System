import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../providers/driver_provider.dart';
import '../../providers/employee_provider.dart';
import '../../providers/trip_provider.dart';
import '../../providers/vehicle_provider.dart';

import '../../routes/app_router.dart';
import 'live_tracking/admin_live_tracking_screen.dart';
import '../../widgets/app_drawer.dart';
import '../../widgets/dashboard_card.dart';

import 'driver/driver_list_screen.dart';
import 'employee/employee_list_screen.dart';
import 'trip/trip_list_screen.dart';
import 'vehicle/vehicle_list_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() =>
      _AdminDashboardState();
}

class _AdminDashboardState
    extends State<AdminDashboard> {

  @override
  void initState() {
    super.initState();

    Future.microtask(() async {

      await context
          .read<EmployeeProvider>()
          .loadEmployees();

      await context
          .read<DriverProvider>()
          .loadDrivers();

      await context
          .read<VehicleProvider>()
          .loadVehicles();

      await context
          .read<TripProvider>()
          .loadTrips();
    });
  }
    @override
  Widget build(BuildContext context) {

    final employeeProvider =
        context.watch<EmployeeProvider>();

    final driverProvider =
        context.watch<DriverProvider>();

    final vehicleProvider =
        context.watch<VehicleProvider>();

    final tripProvider =
        context.watch<TripProvider>();

    return Scaffold(

      drawer: const AppDrawer(),

      appBar: AppBar(

        elevation: 0,

        centerTitle: false,

        titleSpacing: 10,

        title: Row(
          children: [

            Container(
              width: 45,
              height: 45,
              padding:
                  const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius:
                    BorderRadius.circular(12),
              ),
              child: Image.asset(
                "assets/images/admin_logo.png",
              ),
            ),

            const SizedBox(width: 12),

            const Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [

                  Text(
                    "Pratik Thorat",
                    style: TextStyle(
                      fontWeight:
                          FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),

                  Text(
                    "Administrator",
                    style: TextStyle(
                      fontSize: 12,
                    ),
                  ),

                ],
              ),
            ),

          ],
        ),

        actions: [

          PopupMenuButton<String>(

            icon: const CircleAvatar(
              child: Icon(Icons.person),
            ),

            onSelected: (value) async {

              if (value == "logout") {

                await context
                    .read<AuthProvider>()
                    .logout();

                if (!mounted) return;

                Navigator.pushNamedAndRemoveUntil(
                  context,
                  AppRouter.login,
                  (_) => false,
                );
              }
            },
                        itemBuilder: (context) => [

              const PopupMenuItem(
                enabled: false,
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [

                    Text(
                      "Pratik Thorat",
                      style: TextStyle(
                        fontWeight:
                            FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),

                    SizedBox(height: 4),

                    Text(
                      "Administrator",
                    ),

                    SizedBox(height: 4),

                    Text(
                      "admin@travel.com",
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                    ),

                  ],
                ),
              ),

              const PopupMenuDivider(),

              const PopupMenuItem(
                value: "logout",
                child: Row(
                  children: [

                    Icon(Icons.logout),

                    SizedBox(width: 10),

                    Text("Logout"),

                  ],
                ),
              ),

            ],

          ),

          const SizedBox(width: 10),

        ],

      ),

      body: RefreshIndicator(

        onRefresh: () async {

          await employeeProvider
              .loadEmployees();

          await driverProvider
              .loadDrivers();

          await vehicleProvider
              .loadVehicles();

          await tripProvider
              .loadTrips();
        },

        child: SingleChildScrollView(

          physics:
              const AlwaysScrollableScrollPhysics(),

          padding:
              const EdgeInsets.all(16),

          child: Column(

            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [
                            Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius:
                      BorderRadius.circular(20),
                  gradient:
                      const LinearGradient(
                    colors: [
                      Color(0xff1565C0),
                      Color(0xff42A5F5),
                    ],
                  ),
                ),

                child: Row(
                  children: [

                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(
                                18),
                      ),
                      child: Padding(
                        padding:
                            const EdgeInsets.all(
                                12),
                        child: Image.asset(
                          "assets/images/admin_logo.png",
                        ),
                      ),
                    ),

                    const SizedBox(width: 20),

                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment
                                .start,
                        children: [

                          Text(
                            "Welcome",
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 16,
                            ),
                          ),

                          SizedBox(height: 4),

                          Text(
                            "Pratik Thorat",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight:
                                  FontWeight.bold,
                              fontSize: 28,
                            ),
                          ),

                          SizedBox(height: 8),

                          Chip(
                            label: Text(
                              "Administrator",
                            ),
                          ),

                        ],
                      ),
                    ),

                  ],
                ),
              ),

              const SizedBox(height: 25),

              const Text(
                "Dashboard Overview",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight:
                      FontWeight.bold,
                ),
              ),

              const SizedBox(height: 18),
                            GridView.count(

                crossAxisCount: 2,

                shrinkWrap: true,

                physics:
                    const NeverScrollableScrollPhysics(),

                crossAxisSpacing: 15,

                mainAxisSpacing: 15,

                childAspectRatio: 1.25,

                children: [

                  DashboardCard(

                    title: "Employees",

                    value: employeeProvider
                        .employees.length
                        .toString(),

                    icon: Icons.people,

                    color: Colors.blue,

                    onTap: () {

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              const EmployeeListScreen(),
                        ),
                      );

                    },

                  ),

                 DashboardCard(
  title: "Live Tracking",

  value: "",

  icon: Icons.location_on,

  color: Colors.red,

  onTap: () {
    Navigator.pushNamed(
      context,
      AppRouter.liveTracking,
    );
  },
),
                  DashboardCard(

                    title: "Drivers",

                    value: driverProvider
                        .drivers.length
                        .toString(),

                    icon: Icons.badge,

                    color: Colors.orange,

                    onTap: () {

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              const DriverListScreen(),
                        ),
                      );

                    },

                  ),

                  DashboardCard(

                    title: "Vehicles",

                    value: vehicleProvider
                        .vehicles.length
                        .toString(),

                    icon:
                        Icons.directions_car,

                    color: Colors.green,

                    onTap: () {

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              const VehicleListScreen(),
                        ),
                      );

                    },

                  ),

                  DashboardCard(

                    title: "Trips",

                    value: tripProvider
                        .trips.length
                        .toString(),

                    icon: Icons.route,

                    color: Colors.deepPurple,

                    onTap: () {

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              const TripListScreen(),
                        ),
                      );

                    },

                  ),

                ],

              ),

              const SizedBox(height: 30),
                            const Text(
                "Quick Actions",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              Row(
                children: [

                  Expanded(
                    child: FilledButton.icon(

                      onPressed: () {

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                const EmployeeListScreen(),
                          ),
                        );

                      },

                      icon: const Icon(
                        Icons.people,
                      ),

                      label: const Text(
                        "Employees",
                      ),
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: FilledButton.icon(

                      onPressed: () {

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                const DriverListScreen(),
                          ),
                        );

                      },

                      icon: const Icon(
                        Icons.badge,
                      ),

                      label: const Text(
                        "Drivers",
                      ),
                    ),
                  ),

                ],
              ),

              const SizedBox(height: 12),

              Row(
                children: [

                  Expanded(
                    child: FilledButton.icon(

                      onPressed: () {

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                const VehicleListScreen(),
                          ),
                        );

                      },

                      icon: const Icon(
                        Icons.directions_car,
                      ),

                      label: const Text(
                        "Vehicles",
                      ),
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: FilledButton.icon(

                      onPressed: () {

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                const TripListScreen(),
                          ),
                        );

                      },

                      icon: const Icon(
                        Icons.route,
                      ),

                      label: const Text(
                        "Trips",
                      ),
                    ),
                  ),

                ],
              ),

              const SizedBox(height: 30),
                            const Text(
                "Trip Statistics",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(16),
                ),
                child: Padding(
                  padding:
                      const EdgeInsets.all(18),
                  child: Column(
                    children: [

                      ListTile(
                        leading: const CircleAvatar(
                          backgroundColor:
                              Colors.orange,
                          child: Icon(
                            Icons.pending_actions,
                            color: Colors.white,
                          ),
                        ),
                        title: const Text(
                          "Pending Trips",
                        ),
                        trailing: Text(
                          tripProvider
                              .pendingTrips.length
                              .toString(),
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                      ),

                      const Divider(),

                      ListTile(
                        leading: const CircleAvatar(
                          backgroundColor:
                              Colors.blue,
                          child: Icon(
                            Icons.assignment,
                            color: Colors.white,
                          ),
                        ),
                        title: const Text(
                          "Assigned Trips",
                        ),
                        trailing: Text(
                          tripProvider
                              .assignedTrips.length
                              .toString(),
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                      ),

                      const Divider(),

                      ListTile(
                        leading: const CircleAvatar(
                          backgroundColor:
                              Colors.deepPurple,
                          child: Icon(
                            Icons.play_circle_fill,
                            color: Colors.white,
                          ),
                        ),
                        title: const Text(
                          "Started Trips",
                        ),
                        trailing: Text(
                          tripProvider
                              .startedTrips.length
                              .toString(),
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                      ),

                      const Divider(),

                      ListTile(
                        leading: const CircleAvatar(
                          backgroundColor:
                              Colors.green,
                          child: Icon(
                            Icons.check_circle,
                            color: Colors.white,
                          ),
                        ),
                        title: const Text(
                          "Completed Trips",
                        ),
                        trailing: Text(
                          tripProvider
                              .completedTrips.length
                              .toString(),
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                      ),

                    ],
                  ),
                ),
              ),

              const SizedBox(height: 30),
                            const Text(
                "System Status",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              Row(
                children: [

                  Expanded(
                    child: Card(
                      elevation: 3,
                      child: Padding(
                        padding:
                            const EdgeInsets.all(16),
                        child: Column(
                          children: [

                            const Icon(
                              Icons.people,
                              color: Colors.blue,
                              size: 38,
                            ),

                            const SizedBox(height: 10),

                            const Text(
                              "Employees",
                            ),

                            const SizedBox(height: 6),

                            Text(
                              employeeProvider
                                  .employees
                                  .length
                                  .toString(),
                              style:
                                  const TextStyle(
                                fontSize: 24,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),

                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: Card(
                      elevation: 3,
                      child: Padding(
                        padding:
                            const EdgeInsets.all(16),
                        child: Column(
                          children: [

                            const Icon(
                              Icons.badge,
                              color: Colors.orange,
                              size: 38,
                            ),

                            const SizedBox(height: 10),

                            const Text(
                              "Drivers",
                            ),

                            const SizedBox(height: 6),

                            Text(
                              driverProvider
                                  .drivers
                                  .length
                                  .toString(),
                              style:
                                  const TextStyle(
                                fontSize: 24,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),

                          ],
                        ),
                      ),
                    ),
                  ),

                ],
              ),

              const SizedBox(height: 12),

              Row(
                children: [

                  Expanded(
                    child: Card(
                      elevation: 3,
                      child: Padding(
                        padding:
                            const EdgeInsets.all(16),
                        child: Column(
                          children: [

                            const Icon(
                              Icons.directions_car,
                              color: Colors.green,
                              size: 38,
                            ),

                            const SizedBox(height: 10),

                            const Text(
                              "Vehicles",
                            ),

                            const SizedBox(height: 6),

                            Text(
                              vehicleProvider
                                  .vehicles
                                  .length
                                  .toString(),
                              style:
                                  const TextStyle(
                                fontSize: 24,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),

                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: Card(
                      elevation: 3,
                      child: Padding(
                        padding:
                            const EdgeInsets.all(16),
                        child: Column(
                          children: [

                            const Icon(
                              Icons.route,
                              color: Colors.deepPurple,
                              size: 38,
                            ),

                            const SizedBox(height: 10),

                            const Text(
                              "Trips",
                            ),

                            const SizedBox(height: 6),

                            Text(
                              tripProvider
                                  .trips
                                  .length
                                  .toString(),
                              style:
                                  const TextStyle(
                                fontSize: 24,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),

                          ],
                        ),
                      ),
                    ),
                  ),

                ],
              ),

              const SizedBox(height: 30),
                            const Text(
                "Recent Activity",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(16),
                ),
                child: Column(
                  children: [

                    ListTile(
                      leading: const CircleAvatar(
                        backgroundColor:
                            Colors.green,
                        child: Icon(
                          Icons.check,
                          color: Colors.white,
                        ),
                      ),
                      title: const Text(
                        "System Ready",
                      ),
                      subtitle: const Text(
                        "All modules loaded successfully.",
                      ),
                    ),

                    const Divider(height: 1),

                    ListTile(
                      leading: const CircleAvatar(
                        backgroundColor:
                            Colors.blue,
                        child: Icon(
                          Icons.route,
                          color: Colors.white,
                        ),
                      ),
                      title: Text(
                        "${tripProvider.trips.length} Trips Available",
                      ),
                      subtitle: const Text(
                        "Trip database synchronized.",
                      ),
                    ),

                    const Divider(height: 1),

                    ListTile(
                      leading: const CircleAvatar(
                        backgroundColor:
                            Colors.orange,
                        child: Icon(
                          Icons.people,
                          color: Colors.white,
                        ),
                      ),
                      title: Text(
                        "${employeeProvider.employees.length} Employees Registered",
                      ),
                      subtitle: const Text(
                        "Employee records are up to date.",
                      ),
                    ),

                    const Divider(height: 1),

                    ListTile(
                      leading: const CircleAvatar(
                        backgroundColor:
                            Colors.deepPurple,
                        child: Icon(
                          Icons.local_shipping,
                          color: Colors.white,
                        ),
                      ),
                      title: Text(
                        "${driverProvider.drivers.length} Drivers Available",
                      ),
                      subtitle: const Text(
                        "Driver database synchronized.",
                      ),
                    ),

                  ],
                ),
              ),

              const SizedBox(height: 30),

              Center(
                child: Text(
                  "Developed By Pratik Thorat",
                  style: TextStyle(
                    color: Colors.grey.shade700,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),

              const SizedBox(height: 20),
                            Center(
                child: OutlinedButton.icon(
                  onPressed: () async {

                    await employeeProvider
                        .loadEmployees();

                    await driverProvider
                        .loadDrivers();

                    await vehicleProvider
                        .loadVehicles();

                    await tripProvider
                        .loadTrips();

                    if (!mounted) return;

                    ScaffoldMessenger.of(context)
                        .showSnackBar(
                      const SnackBar(
                        content: Text(
                          "Dashboard Refreshed Successfully",
                        ),
                      ),
                    );
                  },
                  icon: const Icon(
                    Icons.refresh,
                  ),
                  label: const Text(
                    "Refresh Dashboard",
                  ),
                ),
              ),

              const SizedBox(height: 30),

            ],
          ),
        ),
      ),
    );
  }
}