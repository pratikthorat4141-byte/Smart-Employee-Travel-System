import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../../../models/payment_model.dart';
import '../../../providers/payment_provider.dart';

import '../../../services/payment_pdf_service.dart';
import '../../../services/payment_excel_service.dart';
import '../../../services/payment_share_service.dart';

import 'view_payment_screen.dart';

class PaymentDashboardScreen extends StatefulWidget {
  const PaymentDashboardScreen({
    super.key,
  });

  @override
  State<PaymentDashboardScreen> createState() =>
      _PaymentDashboardScreenState();
}

class _PaymentDashboardScreenState
    extends State<PaymentDashboardScreen> {
  //--------------------------------------------------
  // CONTROLLERS
  //--------------------------------------------------

  final TextEditingController _searchController =
      TextEditingController();

  //--------------------------------------------------
  // SERVICES
  //--------------------------------------------------

  final PaymentPdfService _pdfService =
      PaymentPdfService.instance;

  final PaymentExcelService _excelService =
      PaymentExcelService.instance;

  final PaymentShareService _shareService =
      PaymentShareService.instance;

  //--------------------------------------------------
  // FILTERS
  //--------------------------------------------------

  DateTime? _fromDate;
  DateTime? _toDate;

  //--------------------------------------------------
  // INIT
  //--------------------------------------------------

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PaymentProvider>().loadPayments();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  //--------------------------------------------------
  // DATE PICKER
  //--------------------------------------------------

  Future<void> _pickFromDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _fromDate ?? DateTime.now(),
      firstDate: DateTime(2023),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      setState(() {
        _fromDate = picked;
      });
    }
  }

  Future<void> _pickToDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _toDate ?? DateTime.now(),
      firstDate: DateTime(2023),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      setState(() {
        _toDate = picked;
      });
    }
  }

  //--------------------------------------------------
  // DATE FILTER CARD
  //--------------------------------------------------

  Widget _dateFilterCard() {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [

            Row(
              children: [

                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _pickFromDate,
                    icon: const Icon(Icons.date_range),
                    label: Text(
                      _fromDate == null
                          ? "From Date"
                          : DateFormat(
                              "dd MMM yyyy",
                            ).format(_fromDate!),
                    ),
                  ),
                ),

                const SizedBox(width: 10),

                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _pickToDate,
                    icon: const Icon(Icons.date_range),
                    label: Text(
                      _toDate == null
                          ? "To Date"
                          : DateFormat(
                              "dd MMM yyyy",
                            ).format(_toDate!),
                    ),
                  ),
                ),

              ],
            ),

            if (_fromDate != null ||
                _toDate != null)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: () {
                    setState(() {
                      _fromDate = null;
                      _toDate = null;
                    });
                  },
                  icon: const Icon(Icons.clear),
                  label: const Text(
                    "Clear Filter",
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  //--------------------------------------------------
  // FILTER PAYMENTS
  //--------------------------------------------------

  List<PaymentModel> _filterPayments(
    List<PaymentModel> payments,
  ) {    List<PaymentModel> filtered = List.from(payments);

    if (_searchController.text.trim().isNotEmpty) {
      final keyword = _searchController.text.toLowerCase();

      filtered = filtered.where((payment) {
        return payment.paymentId
                .toLowerCase()
                .contains(keyword) ||
            payment.tripId
                .toLowerCase()
                .contains(keyword) ||
            payment.employeeName
                .toLowerCase()
                .contains(keyword) ||
            payment.paymentStatus
                .toLowerCase()
                .contains(keyword);
      }).toList();
    }

    if (_fromDate != null) {
      filtered = filtered.where((payment) {
        return !payment.paymentDate.isBefore(_fromDate!);
      }).toList();
    }
        if (_toDate != null) {
      final lastDate = DateTime(
        _toDate!.year,
        _toDate!.month,
        _toDate!.day,
        23,
        59,
        59,
      );

      filtered = filtered.where((payment) {
        return !payment.paymentDate.isAfter(lastDate);
      }).toList();
    }

    return filtered;
  }

  //--------------------------------------------------
  // MESSAGE
  //--------------------------------------------------

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }
  //--------------------------------------------------
// EXPORT PDF
//--------------------------------------------------

Future<void> _exportPdf(
  PaymentModel payment,
) async {
  try {
    final file =
        await _pdfService.generateInvoice(
      payment,
    );

    _showMessage(
      "PDF Saved:\n${file.path}",
    );
  } catch (e) {
    _showMessage(
      "PDF Export Failed\n$e",
    );
  }
}
//--------------------------------------------------
// EXPORT EXCEL
//--------------------------------------------------

Future<void> _exportExcel(
  List<PaymentModel> payments,
) async {
  try {
    final file =
        await _excelService.exportPayments(
      payments,
    );

    _showMessage(
      "Excel Saved:\n${file.path}",
    );
  } catch (e) {
    _showMessage(
      "Excel Export Failed\n$e",
    );
  }
}
//--------------------------------------------------
// SHARE PDF
//--------------------------------------------------

Future<void> _sharePdf(
  PaymentModel payment,
) async {
  try {
    final File file =
        await _pdfService.generateInvoice(
      payment,
    );

    await _shareService.shareFile(
      file,
      subject: "Payment Invoice",
      text:
          "Payment Invoice - ${payment.invoiceNumber}",
    );
  } catch (e) {
    _showMessage(
      "Share Failed\n$e",
    );
  }
}
//--------------------------------------------------
// PRINT PDF
//--------------------------------------------------

Future<void> _printPdf(
  PaymentModel payment,
) async {
  try {
    final File file =
        await _pdfService.generateInvoice(
      payment,
    );

    await Printing.layoutPdf(
      onLayout: (_) async =>
          file.readAsBytes(),
    );
  } catch (e) {
    _showMessage(
      "Print Failed\n$e",
    );
  }
}
//--------------------------------------------------
// DELETE PAYMENT
//--------------------------------------------------

Future<void> _deletePayment(
  PaymentModel payment,
) async {
  final provider =
      context.read<PaymentProvider>();

  final success =
      await provider.deletePayment(
    payment.id!,
  );

  if (!mounted) return;

  _showMessage(
    success
        ? "Payment deleted successfully."
        : "Unable to delete payment.",
  );
}
//--------------------------------------------------
// CONFIRM DELETE
//--------------------------------------------------

Future<void> _confirmDelete(
  PaymentModel payment,
) async {
  final result =
      await showDialog<bool>(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Text(
          "Delete Payment",
        ),
        content: Text(
          "Delete ${payment.paymentId} ?",
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(
                context,
                false,
              );
            },
            child: const Text(
              "Cancel",
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(
                context,
                true,
              );
            },
            child: const Text(
              "Delete",
            ),
          ),
        ],
      );
    },
  );

  if (result == true) {
    await _deletePayment(
      payment,
    );
  }
}
//--------------------------------------------------
// BUILD
//--------------------------------------------------

@override
Widget build(
  BuildContext context,
) {
  return Consumer<PaymentProvider>(
    builder: (
      context,
      provider,
      child,
    ) {
      final payments =
          _filterPayments(
        provider.payments,
      );

      return Scaffold(
        appBar: AppBar(
          title: const Text(
            "Payment Dashboard",
          ),
          centerTitle: true,
        ),

        body: Column(
          children: [

            //--------------------------------------------------
            // SEARCH
            //--------------------------------------------------

            Padding(
              padding:
                  const EdgeInsets.all(16),
              child: TextField(
                controller:
                    _searchController,
                decoration:
                    InputDecoration(
                  hintText:
                      "Search Payment...",
                  prefixIcon:
                      const Icon(
                    Icons.search,
                  ),
                  suffixIcon:
                      IconButton(
                    icon: const Icon(
                      Icons.clear,
                    ),
                    onPressed: () {
                      _searchController
                          .clear();
                      setState(() {});
                    },
                  ),
                  border:
                      OutlineInputBorder(
                    borderRadius:
                        BorderRadius.circular(
                      10,
                    ),
                  ),
                ),
                onChanged: (_) {
                  setState(() {});
                },
              ),
            ),
              //--------------------------------------------------
  // DATE FILTER CARD
  //--------------------------------------------------

  
Widget _dateFilterCard() {
  return Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickFromDate,
                  icon: const Icon(Icons.date_range),
                  label: Text(
                    _fromDate == null
                        ? "From Date"
                        : DateFormat("dd MMM yyyy").format(_fromDate!),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickToDate,
                  icon: const Icon(Icons.event),
                  label: Text(
                    _toDate == null
                        ? "To Date"
                        : DateFormat("dd MMM yyyy").format(_toDate!),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () {
                setState(() {
                  _fromDate = null;
                  _toDate = null;
                });
              },
              icon: const Icon(Icons.clear),
              label: const Text("Clear Filter"),
            ),
          ),
        ],
      ),
    ),
  );
}