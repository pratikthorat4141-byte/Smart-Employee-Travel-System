import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../models/payment_model.dart';
import '../../models/trip_model.dart';

import '../../providers/payment_provider.dart';
import '../../providers/trip_provider.dart';

import '../../services/payment_gateway_service.dart';

class PaymentScreen extends StatefulWidget {
  final TripModel trip;

  const PaymentScreen({
    super.key,
    required this.trip,
  });

  @override
  State<PaymentScreen> createState() =>
      _PaymentScreenState();
}

class _PaymentScreenState
    extends State<PaymentScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController
      _nameController =
      TextEditingController();

  final TextEditingController
      _emailController =
      TextEditingController();

  final TextEditingController
      _mobileController =
      TextEditingController();

  final TextEditingController
      _remarksController =
      TextEditingController();

  bool _processing = false;

  late double amount;
  late double gst;
  late double total;

  @override
  void initState() {
    super.initState();

    amount = widget.trip.totalDistance * 20;

    gst = amount * 0.18;

    total = amount + gst;

    _nameController.text =
        "Employee ${widget.trip.employeeId}";

    _emailController.text =
        "employee${widget.trip.employeeId}@gmail.com";

    _mobileController.text =
        "9999999999";

    PaymentGatewayService.initialize(
      onSuccess: _paymentSuccess,
      onFailure: _paymentFailure,
      onExternalWallet:
          _externalWallet,
    );
  }

  @override
  void dispose() {
    PaymentGatewayService.dispose();

    _nameController.dispose();
    _emailController.dispose();
    _mobileController.dispose();
    _remarksController.dispose();

    super.dispose();
  }

  void _payNow() {
    if (!_formKey.currentState!
        .validate()) {
      return;
    }

    PaymentGatewayService.openPayment(
      customerName:
          _nameController.text.trim(),
      email:
          _emailController.text.trim(),
      contact:
          _mobileController.text.trim(),
      amount: total,
      description:
          "Trip ${widget.trip.tripId}",
    );
  }

  void _paymentSuccess(response) async {
    setState(() {
      _processing = true;
    });

    final payment = PaymentModel(
      paymentId: const Uuid().v4(),

      tripId: widget.trip.tripId,

      employeeId:
          widget.trip.employeeId,

      employeeName:
          _nameController.text,

      driverId:
          widget.trip.driverId,

      amount: amount,

      gst: gst,

      totalAmount: total,

      paymentMethod: "Razorpay",

      paymentStatus: "Paid",

      transactionId:
          response.paymentId ?? "",

      invoiceNumber:
          "INV${DateTime.now().millisecondsSinceEpoch}",

      paymentDate:
          DateTime.now(),

      createdAt:
          DateTime.now(),

      remarks:
          _remarksController.text,
    );

    final provider =
        context.read<PaymentProvider>();

    await provider.addPayment(payment);

    await context
        .read<TripProvider>()
        .updateStatus(
          widget.trip.id!,
          "Completed",
        );
        //==========================================================
// PAYMENT BUTTON
//==========================================================

SizedBox(
  width: double.infinity,
  height: 55,
  child: ElevatedButton.icon(
    icon: const Icon(Icons.payment),
    label: const Text(
      "Pay Now",
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
    ),
    onPressed: () async {
      PaymentGatewayService.openPayment(
        customerName: widget.employeeName,
        email: widget.email,
        contact: widget.mobile,
        amount: totalAmount,
        description:
            "Trip Payment - ${widget.tripId}",
      );
    },
  ),
),

const SizedBox(height: 20),

const Divider(),

const SizedBox(height: 10),

const Text(
  "Payment Information",
  style: TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
  ),
),

const SizedBox(height: 15),

_buildTile(
  "Trip ID",
  widget.tripId,
),

_buildTile(
  "Employee",
  widget.employeeName,
),

_buildTile(
  "Amount",
  "₹${widget.amount.toStringAsFixed(2)}",
),

_buildTile(
  "GST (18%)",
  "₹${gst.toStringAsFixed(2)}",
),

_buildTile(
  "Total",
  "₹${totalAmount.toStringAsFixed(2)}",
),

const SizedBox(height: 30),
],
),
),
),
);
}

//==========================================================
// TILE
//==========================================================

Widget _buildTile(
  String title,
  String value,
) {
  return Padding(
    padding: const EdgeInsets.symmetric(
      vertical: 6,
    ),
    child: Row(
      mainAxisAlignment:
          MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    ),
  );
}

@override
void dispose() {
  PaymentGatewayService.dispose();
  super.dispose();
}
}