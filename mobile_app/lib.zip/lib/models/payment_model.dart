class PaymentModel {
  final int? id;

  final String paymentId;
  final String tripId;

  final int employeeId;
  final String employeeName;

  final int driverId;

  final double amount;
  final double gst;
  final double totalAmount;

  final String paymentMethod;
  final String paymentStatus;

  final String transactionId;
  final String invoiceNumber;

  final DateTime paymentDate;
  final DateTime createdAt;

  final String remarks;

  const PaymentModel({
    this.id,
    required this.paymentId,
    required this.tripId,
    required this.employeeId,
    required this.employeeName,
    required this.driverId,
    required this.amount,
    required this.gst,
    required this.totalAmount,
    required this.paymentMethod,
    required this.paymentStatus,
    required this.transactionId,
    required this.invoiceNumber,
    required this.paymentDate,
    required this.createdAt,
    required this.remarks,
  });

  double get baseAmount => amount;

  double get gstAmount => gst;

  PaymentModel copyWith({
    int? id,
    String? paymentId,
    String? tripId,
    int? employeeId,
    String? employeeName,
    int? driverId,
    double? amount,
    double? gst,
    double? totalAmount,
    String? paymentMethod,
    String? paymentStatus,
    String? transactionId,
    String? invoiceNumber,
    DateTime? paymentDate,
    DateTime? createdAt,
    String? remarks,
  }) {
    return PaymentModel(
      id: id ?? this.id,
      paymentId: paymentId ?? this.paymentId,
      tripId: tripId ?? this.tripId,
      employeeId: employeeId ?? this.employeeId,
      employeeName: employeeName ?? this.employeeName,
      driverId: driverId ?? this.driverId,
      amount: amount ?? this.amount,
      gst: gst ?? this.gst,
      totalAmount: totalAmount ?? this.totalAmount,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      transactionId: transactionId ?? this.transactionId,
      invoiceNumber: invoiceNumber ?? this.invoiceNumber,
      paymentDate: paymentDate ?? this.paymentDate,
      createdAt: createdAt ?? this.createdAt,
      remarks: remarks ?? this.remarks,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'paymentId': paymentId,
      'tripId': tripId,
      'employeeId': employeeId,
      'employeeName': employeeName,
      'driverId': driverId,
      'amount': amount,
      'gst': gst,
      'totalAmount': totalAmount,
      'paymentMethod': paymentMethod,
      'paymentStatus': paymentStatus,
      'transactionId': transactionId,
      'invoiceNumber': invoiceNumber,
      'paymentDate': paymentDate.toIso8601String(),
      'createdAt': createdAt.toIso8601String(),
      'remarks': remarks,
    };
  }

  factory PaymentModel.fromMap(Map<String, dynamic> map) {
    return PaymentModel(
      id: map['id'] as int?,
      paymentId: map['paymentId'] ?? '',
      tripId: map['tripId'] ?? '',
      employeeId: map['employeeId'] ?? 0,
      employeeName: map['employeeName'] ?? '',
      driverId: map['driverId'] ?? 0,
      amount: (map['amount'] ?? 0).toDouble(),
      gst: (map['gst'] ?? 0).toDouble(),
      totalAmount: (map['totalAmount'] ?? 0).toDouble(),
      paymentMethod: map['paymentMethod'] ?? '',
      paymentStatus: map['paymentStatus'] ?? '',
      transactionId: map['transactionId'] ?? '',
      invoiceNumber: map['invoiceNumber'] ?? '',
      paymentDate: DateTime.tryParse(
            map['paymentDate'] ?? '',
          ) ??
          DateTime.now(),
      createdAt: DateTime.tryParse(
            map['createdAt'] ?? '',
          ) ??
          DateTime.now(),
      remarks: map['remarks'] ?? '',
    );
  }

  @override
  String toString() {
    return '''
PaymentModel(
id: $id,
paymentId: $paymentId,
tripId: $tripId,
employeeId: $employeeId,
employeeName: $employeeName,
driverId: $driverId,
amount: $amount,
gst: $gst,
totalAmount: $totalAmount,
paymentMethod: $paymentMethod,
paymentStatus: $paymentStatus,
transactionId: $transactionId,
invoiceNumber: $invoiceNumber,
paymentDate: $paymentDate,
createdAt: $createdAt,
remarks: $remarks
)
''';
  }
}